export EXTERNAL_STORAGE=/mnt/sdcard
export PYTHONPATH=/mnt/sdcard/com.googlecode.pythonforandroid/extras/python:/data/data/com.googlecode.pythonforandroid/files/python/lib/python2.7/lib-dynload:/data/data/com.googlecode.pythonforandroid/files/python/lib/python2.7
export TEMP=/mnt/sdcard/com.googlecode.pythonforandroid/extras/python/tmp
export PYTHON_EGG_CACHE=$TEMP
export PYTHONHOME=/data/data/com.googlecode.pythonforandroid/files/python
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/data/data/com.googlecode.pythonforandroid/files/python/lib:/data/data/com.googlecode.pythonforandroid/files/python/lib/python2.7/lib-dynload:/mnt/sdcard/com.googlecode.pythonforandroid/extras/python
/data/data/com.googlecode.pythonforandroid/files/python/bin/python "$@"