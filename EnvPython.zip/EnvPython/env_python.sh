export EXTERNAL_STORAGE=/mnt/sdcard
export PYTHONPATH=/data/data/com.spaceaa.installenv/files/EnvPython/Extras/python:/data/data/com.spaceaa.installenv/files/EnvPython/Python/lib/python2.7/lib-dynload:/data/data/com.spaceaa.installenv/files/EnvPython/Python/lib/python2.7
export TEMP=/data/data/com.spaceaa.installenv/files/EnvPython/Extras/python/tmp
export PYTHON_EGG_CACHE=$TEMP
export PYTHONHOME=/data/data/com.spaceaa.installenv/files/EnvPython/Python
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/data/data/com.spaceaa.installenv/files/EnvPython/Python/lib:/data/data/com.spaceaa.installenv/files/EnvPython/Python/lib/python2.7/lib-dynload:/data/data/com.spaceaa.installenv/files/EnvPython/Extras/python
/data/data/com.spaceaa.installenv/files/EnvPython/Python/bin/python "$@"